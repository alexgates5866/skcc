<?php

if ($_SERVER['REQUEST_METHOD'] == "POST")
{
    extract($_POST);
}
elseif ($_SERVER['REQUEST_METHOD'] == "GET")
{
    extract($_GET);
}