<?php

// Function
require(dirname(__FILE__) . '/Curl/Function/getstr.php');
require(dirname(__FILE__) . '/Curl/Function/instr.php');
require(dirname(__FILE__) . '/Curl/Function/divider.php');
require(dirname(__FILE__) . '/Curl/Function/value.php');
require(dirname(__FILE__) . '/Curl/Function/Array.php');
require(dirname(__FILE__) . '/Curl/Function/saveCCN.php');
require(dirname(__FILE__) . '/Curl/Function/saveCVV.php');
require(dirname(__FILE__) . '/Curl/Function/r-error.php');
require(dirname(__FILE__) . '/Curl/Function/bin.php');
require(dirname(__FILE__) . '/Curl/Function/r_method.php');
require(dirname(__FILE__) . '/Curl/Function/ids.php');
