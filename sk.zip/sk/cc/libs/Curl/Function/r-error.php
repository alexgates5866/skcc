<?php

//Randomize Api
$url = 'https://randomuser.me/api/?nat=us'; //URL Path
$json = file_get_contents($url); //Putting content into variable

$response = json_decode($json, true);

$firstname = $response['results'][0]['name']['first'];
$lastname = $response['results'][0]['name']['last'];
$streetname = $response['results'][0]['location']['street']['name'];
$streetnum = $response['results'][0]['location']['street']['number'];
$street = $streetnum." ".$streetname;
$city = $response['results'][0]['location']['city'];
$state = $response['results'][0]['location']['state'];
$zip = $response['results'][0]['location']['postcode'];
$email = $response['results'][0]['email'];
$ran_num = rand(10,1000);
$ran_num2 = rand(10,3000);
$numm = rand(1,9);

?>