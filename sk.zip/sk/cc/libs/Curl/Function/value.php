<?php

function value($str, $find_start, $find_end)
{
    $start = @strpos($str, $find_start);
    if ($start === false)
    {
        return "";
    }
    $length = strlen($find_start);
    $end = strpos(substr($str, $start + $length) , $find_end);
    return trim(substr($str, $start + $length, $end));
}