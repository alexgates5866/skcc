<?php
#======================= [ SAVE CCN LIVES ] ====================#
function saveCCN($cc)
{
    $file = dirname(__FILE__) . "/CCN_Lives.txt";
    $fp = fopen($file, "a+");
    fwrite($fp, $cc . PHP_EOL);
    fclose($fp);
}