<?php
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://m.stripe.com/6');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'JTdCJTIydjIlMjIlM0ExJTJDJTIyaWQlMjIlM0ElMjI4Yzc1Mzk1N2VlM2JjZDQ4Y2E1ZjU3YWI4NGU4YWQ4YyUyMiUyQyUyMnQlMjIlM0E0NzAyLjYlMkMlMjJ0YWclMjIlM0ElMjI0LjUuMjglMjIlMkMlMjJzcmMlMjIlM0ElMjJqcyUyMiUyQyUyMmElMjIlM0ElN0IlMjJhJTIyJTNBJTdCJTIydiUyMiUzQSUyMmZhbHNlJTIyJTJDJTIydCUyMiUzQTAuNiU3RCUyQyUyMmIlMjIlM0ElN0IlMjJ2JTIyJTNBJTIyZmFsc2UlMjIlMkMlMjJ0JTIyJTNBMC4wNzUlN0QlMkMlMjJjJTIyJTNBJTdCJTIydiUyMiUzQSUyMmVuLVVTJTJDZW4lMjIlMkMlMjJ0JTIyJTNBMC4xJTdEJTJDJTIyZCUyMiUzQSU3QiUyMnYlMjIlM0ElMjJXaW4zMiUyMiUyQyUyMnQlMjIlM0EwLjA1JTdEJTJDJTIyZSUyMiUzQSU3QiUyMnYlMjIlM0ElMjJDaHJvbWUlMjBQREYlMjBWaWV3ZXIlMkNtaGpmYm1kZ2NmamJicGFlb2pvZm9ob2VmZ2llaGphaSUyQ2FwcGxpY2F0aW9uJTJGcGRmJTJDcGRmJTJDJTIwUUlFQ0JndyUyQ2d3WXMyYnQyYk5tejVjdSUyQyUyQyUyQyUyMENocm9tZSUyMFBERiUyMFBsdWdpbiUyQ2ludGVybmFsLXBkZi12aWV3ZXIlMkNhcHBsaWNhdGlvbiUyRngtZ29vZ2xlLWNocm9tZS1wZGYlMkNwZGYlMkMlMjA4LiUyMCUyMCUyMCUyMGZQJTJDWnNXTEZDQmdRSWt5NWNPSCUyQyUyQyUyMiUyQyUyMnQlMjIlM0EwLjg4NSU3RCUyQyUyMmYlMjIlM0ElN0IlMjJ2JTIyJTNBJTIyMTYwMHdfODYwaF8yNGRfMXIlMjIlMkMlMjJ0JTIyJTNBMC4wNyU3RCUyQyUyMmclMjIlM0ElN0IlMjJ2JTIyJTNBJTIyOCUyMiUyQyUyMnQlMjIlM0EwLjA1NSU3RCUyQyUyMmglMjIlM0ElN0IlMjJ2JTIyJTNBJTIyZmFsc2UlMjIlMkMlMjJ0JTIyJTNBMC4wNyU3RCUyQyUyMmklMjIlM0ElN0IlMjJ2JTIyJTNBJTIyc2Vzc2lvblN0b3JhZ2UtdW5hdmFpbGFibGUlMkMlMjBsb2NhbFN0b3JhZ2UtdW5hdmFpbGFibGUlMjIlMkMlMjJ0JTIyJTNBMjQuMDIlN0QlMkMlMjJqJTIyJTNBJTdCJTIydiUyMiUzQSUyMjAxMDAxMDAxMDExMTExMTExMDAxMTExMDExMTExMTExMDExMTEwMTAxMTAxMTExMTAxMTExMTElMjIlMkMlMjJ0JTIyJTNBNDY3NS44JTJDJTIyYXQlMjIlM0EzNzUzLjUlN0QlMkMlMjJrJTIyJTNBJTdCJTIydiUyMiUzQSUyMiUyMiUyQyUyMnQlMjIlM0EwLjA5JTdEJTJDJTIybCUyMiUzQSU3QiUyMnYlMjIlM0ElMjJNb3ppbGxhJTJGNS4wJTIwKFdpbmRvd3MlMjBOVCUyMDEwLjAlM0IlMjBXaW42NCUzQiUyMHg2NCklMjBBcHBsZVdlYktpdCUyRjUzNy4zNiUyMChLSFRNTCUyQyUyMGxpa2UlMjBHZWNrbyklMjBDaHJvbWUlMkY4NC4wLjQxNDcuMTM1JTIwU2FmYXJpJTJGNTM3LjM2JTIyJTJDJTIydCUyMiUzQTAuMDclN0QlMkMlMjJtJTIyJTNBJTdCJTIydiUyMiUzQSUyMiUyMiUyQyUyMnQlMjIlM0EwLjI3JTdEJTJDJTIybiUyMiUzQSU3QiUyMnYlMjIlM0ElMjJmYWxzZSUyMiUyQyUyMnQlMjIlM0ExMTQyLjIlMkMlMjJhdCUyMiUzQTUlN0QlMkMlMjJvJTIyJTNBJTdCJTIydiUyMiUzQSUyMjEzYzJjM2Q1Njk3YjdlZDdkOTFiZjA2ZDlmNTkyODc4JTIyJTJDJTIydCUyMiUzQTc5NC43MiU3RCU3RCUyQyUyMmIlMjIlM0ElN0IlMjJhJTIyJTNBJTIyJTIyJTJDJTIyYiUyMiUzQSUyMmh0dHBzJTNBJTJGJTJGd3d3LmluZmluaXRldXBjeWNsZS5jb20lMkZzdWJzY3JpcHRpb24lMkYlMjIlMkMlMjJjJTIyJTNBJTIyU3Vic2NyaXB0aW9uJTIwJTdDJTIwSW5maW5pdGUlMjBVcGN5Y2xlJTIyJTJDJTIyZCUyMiUzQSUyMjA2MzY2Y2E2LWNkMjUtNGRiYi05MjY2LTUzZTAzNjk3NDlhM2M1MTljYiUyMiUyQyUyMmUlMjIlM0ElMjJiZjZkMDk5YS00MDNmLTQyYTUtODMwNy1jYmI0MGM5OTJmOGExNmI4ZWUlMjIlMkMlMjJmJTIyJTNBZmFsc2UlMkMlMjJnJTIyJTNBdHJ1ZSUyQyUyMmglMjIlM0F0cnVlJTJDJTIyaSUyMiUzQSU1QiUyMmxvY2F0aW9uJTIyJTVEJTJDJTIyaiUyMiUzQSU1QiU1RCUyQyUyMm4lMjIlM0E4NDAuODkwMDAwMDA2NzY2MSU3RCU3RA==');
curl_setopt($ch, CURLOPT_HEADER, 0);
//// Short codes $cc $mes $ano $cvv $firstname $lastname $street $zip $phone $state $email/////////////////////
$headers = array();
$headers[] = 'authority: m.stripe.com';
$headers[] = 'content-type: text/plain;charset=UTF-8';
$headers[] = 'origin: https://m.stripe.network';
$headers[] = 'referer: https://m.stripe.network/';
$headers[] = 'sec-fetch-dest: empty';
$headers[] = 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.105 Safari/537.36';
$headers[] = 'sec-fetch-mode: cors';
$headers[] = 'sec-fetch-site: cross-site';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$resultt = curl_exec($ch);
$muid = trim(strip_tags(getStr($resultt, '"muid":"','"')));
$guid = trim(strip_tags(getStr($resultt, '"guid":"','"')));
$sid = trim(strip_tags(getStr($resultt, '"sid":"','"')));
