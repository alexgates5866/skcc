<?php

$lista = $_GET['lista'];
$divide = explode("|", $lista);
$cc = $divide[0];
$month = $divide[1];
$year = $divide[2];
$cvv = $divide[3];
$bins = substr($cc, 0, 6);
$last4 = substr($cc, 12, 16);